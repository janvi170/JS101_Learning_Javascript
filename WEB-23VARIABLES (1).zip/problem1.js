let name1= "Masai School";
name2= "A Transformation in Education";
console.log(name1);
console.log(name2);