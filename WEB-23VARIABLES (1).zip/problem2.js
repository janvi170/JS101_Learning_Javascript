var myName= "My name : Janvi sharma";
var fatherName="Father's name : Madan mohan";
var motherName="Mother's name : Suman sharma";
console.log(myName);
console.log(fatherName);
console.log(motherName);