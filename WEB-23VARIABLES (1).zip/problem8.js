let databaseUser="xyz@gmail.com";
let databasePass="890yui";

let user="xyz@gmail.com";
let pass="890yui";
if(databaseUser==user){
  if(databasePass==pass){
    console.log("Login Successfull");
  }else{
    console.log("Incorrect Password");
  }
  }else{
    console.log("Wrong Condentials");
  
}