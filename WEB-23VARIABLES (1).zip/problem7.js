let a=30;
let b=50;
if(a>b){
  console.log(a, "is greater");
}else if(b>a){
  console.log(b, "is greater");
}else{
  console.log("Both are equal");
}