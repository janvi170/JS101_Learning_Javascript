
let y=23;
y=29;
console.log(y);