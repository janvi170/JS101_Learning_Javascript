let x=30;
if(x%3==0){
  console.log("multiple of 3");
}
  