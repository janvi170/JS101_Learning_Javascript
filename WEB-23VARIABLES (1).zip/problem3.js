var name="Name : janvi sharma";
var age="Age : 20";
console.log(name);
console.log(age);