var reportCard="              *Report Card*        "
var name="* Name : Janvi sharma ";
var school="* School : kendriya vidyalaya ";
var grade="* Grade : 12th "
var section="* Section : A ";
var rollno= "* Rollno : 10 ";

var subject1="* English : 90/100";
var subject2="* Hindi : 89/100";
var subject3="* Maths : 78/100";
console.log(reportCard);
console.log(name);
console.log(school);
console.log(grade);
console.log(section);
console.log(rollno);

console.log(subject1);
console.log(subject2);
console.log(subject3);


