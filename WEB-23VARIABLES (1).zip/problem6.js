let age=19;
let legal_age=18;
if(age>=legal_age){
  console.log("Apply for a license");
}else{
  console.log("NA");
}